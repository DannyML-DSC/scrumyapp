from django.apps import AppConfig


class DannyscrumyConfig(AppConfig):
    name = 'dannyscrumy'
